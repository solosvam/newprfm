{{--
  Əsas səhifə: admin/operator paneli.
  $dashboard = ['period', 'stats' (AdminDashboard::stats), 'sales' (son 7 gün), 'active' (aktiv sifariş mərhələləri)]
--}}
@use('App\Services\Dashboard\AdminDashboard')
@php
    $money = fn ($v, $d = 0) => number_format((float) $v, $d, '.', ' ');
    $cards = [
        ['key' => 'revenue', 'title' => 'Dövriyyə', 'icon' => 'money', 'format' => fn ($v) => $money($v).' ₼'],
        ['key' => 'orders', 'title' => 'Sifarişlər', 'icon' => 'cart', 'format' => fn ($v) => $money($v)],
        ['key' => 'average', 'title' => 'Orta sifariş', 'icon' => 'basket', 'format' => fn ($v) => $money($v, 2).' ₼'],
        ['key' => 'customers', 'title' => 'Yeni müştərilər', 'icon' => 'user', 'format' => fn ($v) => $money($v)],
    ];
    $previousLabel = ['today' => 'Dünən bu vaxta qədər', 'week' => 'Əvvəlki 7 gün', 'month' => 'Əvvəlki 30 gün'][$dashboard['period']];
    $sales = $dashboard['sales'];
    $activeTotal = array_sum(array_column($dashboard['active'], 'count'));
@endphp

<div class="row">
    {{-- Statistika (dövr seçimi ilə) --}}
    <div class="col-12 col-xl-6 mb-5">
        <div class="d-flex align-items-center">
            <div class="dropdown me-3">
                <a class="pe-0 pt-0 align-top lh-1 dropdown-toggle small-title" href="#" data-bs-toggle="dropdown" aria-expanded="false" aria-haspopup="true">
                    {{ AdminDashboard::PERIODS[$dashboard['period']] }}
                </a>
                <div class="dropdown-menu font-standard">
                    @foreach(AdminDashboard::PERIODS as $key => $label)
                        <a class="dropdown-item text-medium {{ $key === $dashboard['period'] ? 'active' : '' }}"
                           href="{{ route('admin.main', ['period' => $key]) }}">{{ $label }}</a>
                    @endforeach
                </div>
            </div>
            <h2 class="small-title">Statistika</h2>
        </div>
        <div class="row g-2">
            @foreach($cards as $card)
                @php($m = $dashboard['stats'][$card['key']])
                <div class="col-12 col-sm-6">
                    <div class="card h-100">
                        <div class="h-100 row g-0 card-body align-items-center py-4">
                            <div class="col-auto">
                                <div class="bg-gradient-light sw-6 sh-6 rounded-md d-flex justify-content-center align-items-center">
                                    <i data-acorn-icon="{{ $card['icon'] }}" class="text-white"></i>
                                </div>
                            </div>
                            <div class="col ps-3 d-flex flex-column justify-content-center">
                                <div class="heading mb-1 lh-1-25">{{ $card['title'] }}</div>
                                <div class="row g-0 align-items-center">
                                    <div class="col-auto">
                                        <div class="cta-2 text-primary">{{ $card['format']($m['value']) }}</div>
                                    </div>
                                    @if($m['change'] !== null)
                                        <div class="col {{ $m['change'] >= 0 ? 'text-success' : 'text-danger' }} d-flex align-items-center ps-3">
                                            <i data-acorn-icon="{{ $m['change'] >= 0 ? 'arrow-top' : 'arrow-bottom' }}" class="me-1" data-acorn-size="13"></i>
                                            <span class="text-medium">{{ ($m['change'] > 0 ? '+' : '').$m['change'] }}%</span>
                                        </div>
                                    @endif
                                </div>
                                <div class="text-small text-muted mt-1">{{ $previousLabel }}: {{ $card['format']($m['previous']) }}</div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    {{-- Satış dinamikası: son 7 gün --}}
    <div class="col-12 col-xl-6 mb-5">
        <h2 class="small-title">Satış — son 7 gün</h2>
        @foreach([
            ['id' => 'dashRevenueChart', 'label' => 'Dövriyyə, ₼', 'data' => $sales['revenue'], 'total' => $money(array_sum($sales['revenue'])).' ₼', 'avg' => $money(array_sum($sales['revenue']) / 7).' ₼', 'color' => 'primary'],
            ['id' => 'dashOrdersChart', 'label' => 'Sifarişlər', 'data' => $sales['orders'], 'total' => array_sum($sales['orders']), 'avg' => $money(array_sum($sales['orders']) / 7, 1), 'color' => 'secondary'],
        ] as $chart)
            <div class="card h-auto sh-xl-24 {{ $loop->first ? 'mb-2' : '' }}">
                <div class="card-body">
                    <div class="row g-0 h-100 chart-container">
                        {{-- Yuxarı hissəni (seçilmiş gün) charts.extend.js doldurur --}}
                        <div class="col-12 col-sm-auto d-flex flex-column justify-content-between custom-tooltip pe-0 pe-sm-4 sw-sm-19">
                            <p class="heading title mb-1"></p>
                            <div>
                                <div>
                                    <div class="cta-2 text-{{ $chart['color'] }} value d-inline-block align-middle"></div>
                                    <i class="icon d-inline-block align-middle text-{{ $chart['color'] }}" data-acorn-size="15"></i>
                                </div>
                                <div class="text-small text-muted mb-1 text"></div>
                            </div>
                            <div class="row">
                                <div class="col-auto">
                                    <div class="cta-3 text-alternate">{{ $chart['total'] }}</div>
                                    <div class="text-small text-muted mb-1">7 GÜN</div>
                                </div>
                                <div class="col">
                                    <div class="cta-3 text-alternate">{{ $chart['avg'] }}</div>
                                    <div class="text-small text-muted mb-1">GÜNDƏ ORTA</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm sh-17">
                            <canvas id="{{ $chart['id'] }}" class="dashboard-line-chart"
                                    data-label="{{ $chart['label'] }}"
                                    data-color="{{ $chart['color'] }}"
                                    data-labels='@json($sales['labels'])'
                                    data-values='@json($chart['data'])'></canvas>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

{{-- Aktiv sifarişlər mərhələlər üzrə --}}
<div class="mb-5">
    <div class="d-flex justify-content-between align-items-center">
        <h2 class="small-title">Aktiv sifarişlər</h2>
        <span class="text-small text-muted mb-2">Cəmi: {{ $activeTotal }}</span>
    </div>
    <div class="row g-2 row-cols-1 row-cols-sm-2 row-cols-lg-4 dashboard-steps">
        @foreach($dashboard['active'] as $step)
            <div class="col">
                <div class="card h-100 {{ $step['count'] ? '' : 'opacity-50' }}">
                    <div class="card-body text-center d-flex flex-column align-items-center py-4">
                        <div class="{{ $step['count'] ? 'bg-gradient-light' : 'border border-primary' }} sw-6 sh-6 rounded-xl d-flex justify-content-center align-items-center mb-3">
                            <i data-acorn-icon="{{ $step['icon'] }}" class="{{ $step['count'] ? 'text-white' : 'text-primary' }}"></i>
                        </div>
                        <div class="heading lh-1-25 mb-2 sh-5 d-flex align-items-center">{{ $step['name'] }}</div>
                        <div class="display-6 text-primary">{{ $step['count'] }}</div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
