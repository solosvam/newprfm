<?php

namespace App\Services\Dashboard;

use App\Models\Customer\Customer;
use App\Models\Order\Order;
use App\Models\Order\OrderStatus;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\Cache;

/**
 * Admin əsas səhifəsinin göstəriciləri.
 * Dövriyyə = ləğv edilməmiş sifarişlərin yekun məbləği (sifariş tarixinə görə).
 * Yeni müştərilər = köhnə sistemdən köçürülənlər (old_customer_id) xaric.
 * Nəticələr qısa müddət keşdə saxlanılır — hər açılışda böyük cədvəllər sayılmasın.
 */
class AdminDashboard
{
    public const PERIODS = [
        'today' => 'Bu gün',
        'week' => 'Son 7 gün',
        'month' => 'Son 30 gün',
    ];

    /** Hələ bitməmiş (aktiv) sifariş mərhələləri — axın sırası ilə */
    public const ACTIVE_STATUSES = [
        'new' => 'send',
        'preparing' => 'box',
        'warehouse_requested' => 'hourglass',
        'warehouses_assigned' => 'boxes',
        'courier_assigned' => 'user',
        'sent' => 'delivery-truck',
        'at_address' => 'pin',
    ];

    private const TTL = 300;

    /**
     * Seçilmiş dövr və ondan əvvəlki eyni uzunluqlu dövr üzrə əsas göstəricilər.
     * "Bu gün" dünənin eyni saatına qədəri ilə müqayisə olunur (səhər saatlarında yanlış "−90%" olmasın).
     *
     * @return array<string, array{value: float|int, previous: float|int, change: ?float}>
     */
    public function stats(string $period): array
    {
        $period = array_key_exists($period, self::PERIODS) ? $period : 'today';

        return Cache::remember("admin-dashboard:stats:$period", self::TTL, function () use ($period) {
            [$from, $to, $prevFrom, $prevTo] = $this->range($period);
            $current = $this->orderTotals($from, $to);
            $previous = $this->orderTotals($prevFrom, $prevTo);

            $customers = fn ($a, $b) => Customer::whereNull('old_customer_id')->whereBetween('created_at', [$a, $b])->count();

            return [
                'orders' => $this->metric($current['count'], $previous['count']),
                'revenue' => $this->metric($current['sum'], $previous['sum']),
                'average' => $this->metric(
                    $current['count'] ? $current['sum'] / $current['count'] : 0,
                    $previous['count'] ? $previous['sum'] / $previous['count'] : 0,
                ),
                'customers' => $this->metric($customers($from, $to), $customers($prevFrom, $prevTo)),
            ];
        });
    }

    /**
     * Son N gün üzrə günlük dövriyyə və sifariş sayı (qrafik üçün, bu gün daxil).
     *
     * @return array{labels: string[], revenue: float[], orders: int[], dates: string[]}
     */
    public function sales(int $days = 7): array
    {
        return Cache::remember("admin-dashboard:sales:$days", self::TTL, function () use ($days) {
            $start = CarbonImmutable::today()->subDays($days - 1);
            $rows = $this->validOrders()
                ->where('created_at', '>=', $start)
                ->selectRaw('DATE(created_at) as day, COUNT(*) as orders, SUM(total) as revenue')
                ->groupBy('day')
                ->get()
                ->keyBy('day');

            $weekdays = ['B.', 'B.e.', 'Ç.a.', 'Ç.', 'C.a.', 'C.', 'Ş.'];
            $result = ['labels' => [], 'dates' => [], 'revenue' => [], 'orders' => []];
            for ($i = 0; $i < $days; $i++) {
                $day = $start->addDays($i);
                $row = $rows->get($day->toDateString());
                $result['labels'][] = $day->isToday() ? 'Bu gün' : $weekdays[$day->dayOfWeek].' '.$day->format('d.m');
                $result['dates'][] = $day->toDateString();
                $result['revenue'][] = round((float) ($row->revenue ?? 0), 2);
                $result['orders'][] = (int) ($row->orders ?? 0);
            }

            return $result;
        });
    }

    /**
     * Aktiv sifarişlərin mərhələlər üzrə sayı (axın sırası ilə, 0 olanlar da göstərilir).
     *
     * @return array<int, array{code: string, name: string, icon: string, count: int}>
     */
    public function activeStatuses(): array
    {
        return Cache::remember('admin-dashboard:active-statuses', 60, function () {
            $statuses = OrderStatus::whereIn('code', array_keys(self::ACTIVE_STATUSES))->get()->keyBy('code');
            $counts = Order::whereIn('order_status_id', $statuses->pluck('id'))
                ->selectRaw('order_status_id, COUNT(*) as total')
                ->groupBy('order_status_id')
                ->pluck('total', 'order_status_id');

            $result = [];
            foreach (self::ACTIVE_STATUSES as $code => $icon) {
                if ($status = $statuses->get($code)) {
                    $result[] = [
                        'code' => $code,
                        'name' => $status->name_az,
                        'icon' => $icon,
                        'count' => (int) ($counts[$status->id] ?? 0),
                    ];
                }
            }

            return $result;
        });
    }

    /** Ləğv edilməmiş sifarişlər */
    private function validOrders()
    {
        $cancelled = OrderStatus::where('code', 'cancelled')->value('id');

        return Order::query()->when($cancelled, fn ($q) => $q->where(
            fn ($w) => $w->where('order_status_id', '!=', $cancelled)->orWhereNull('order_status_id')
        ));
    }

    /** @return array{count: int, sum: float} */
    private function orderTotals(CarbonImmutable $from, CarbonImmutable $to): array
    {
        $row = $this->validOrders()
            ->whereBetween('created_at', [$from, $to])
            ->selectRaw('COUNT(*) as orders, COALESCE(SUM(total), 0) as revenue')
            ->first();

        return ['count' => (int) $row->orders, 'sum' => round((float) $row->revenue, 2)];
    }

    /** @return array{0: CarbonImmutable, 1: CarbonImmutable, 2: CarbonImmutable, 3: CarbonImmutable} */
    private function range(string $period): array
    {
        $now = CarbonImmutable::now();
        if ($period === 'today') {
            $from = $now->startOfDay();

            return [$from, $now, $from->subDay(), $now->subDay()];
        }
        $days = $period === 'week' ? 7 : 30;
        $from = $now->subDays($days);

        return [$from, $now, $from->subDays($days), $from];
    }

    private function metric(float|int $value, float|int $previous): array
    {
        return [
            'value' => $value,
            'previous' => $previous,
            // əvvəlki dövr 0-dırsa faiz mənasızdır
            'change' => $previous > 0 ? round(($value - $previous) / $previous * 100, 1) : null,
        ];
    }
}
