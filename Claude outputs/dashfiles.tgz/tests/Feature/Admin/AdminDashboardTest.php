<?php

namespace Tests\Feature\Admin;

use App\Models\Order\Order;
use App\Models\User;
use App\Services\Dashboard\AdminDashboard;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\Concerns\OrderStatusFixtures;
use Tests\TestCase;

class AdminDashboardTest extends TestCase
{
    use OrderStatusFixtures;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();
        config(['database.default' => 'sqlite', 'database.connections.sqlite.database' => ':memory:', 'cache.default' => 'array']);
        DB::purge('sqlite');
        Schema::create('users', fn (Blueprint $t) => [$t->id(), $t->string('name'), $t->string('surname')->nullable(), $t->string('email')->nullable(), $t->string('password')->nullable(), $t->boolean('active')->default(true), $t->timestamps()]);
        (require base_path('vendor/spatie/laravel-permission/database/migrations/create_permission_tables.php.stub'))->up();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        Schema::create('order_statuses', fn (Blueprint $t) => [$t->id(), $t->string('code'), $t->string('name_az')->nullable()]);
        Schema::create('payment_methods', fn (Blueprint $t) => [$t->id(), $t->string('code'), $t->string('name'), $t->string('name_az')->nullable()]);
        DB::table('payment_methods')->insert([['id' => 1, 'code' => 'cash', 'name' => 'Nağd', 'name_az' => 'Qapıda nağd'], ['id' => 2, 'code' => 'card_online', 'name' => 'Kart', 'name_az' => 'Kartla onlayn'], ['id' => 3, 'code' => 'birbank_installment', 'name' => 'Birbank', 'name_az' => 'Birbank taksit'], ['id' => 4, 'code' => 'installment', 'name' => 'Hissə', 'name_az' => 'Hissə-hissə ödəniş']]);
        Schema::create('orders', fn (Blueprint $t) => [$t->id(), $t->integer('customer_id')->nullable(), $t->unsignedBigInteger('order_status_id')->nullable(), $t->unsignedBigInteger('payment_method_id')->default(1), $t->decimal('total', 12, 2)->default(0), $t->decimal('delivery_fee', 12, 2)->default(0), $t->decimal('gift_wrap_fee', 12, 2)->default(0), $t->timestamps()]);
        Schema::create('order_items', fn (Blueprint $t) => [$t->id(), $t->unsignedBigInteger('order_id'), $t->integer('quantity')->default(1)]);
        Schema::create('order_item_allocations', fn (Blueprint $t) => [$t->id(), $t->unsignedBigInteger('order_item_id'), $t->integer('quantity'), $t->decimal('unit_cost', 12, 2), $t->string('status')]);
        Schema::create('customers', fn (Blueprint $t) => [$t->id(), $t->string('name')->nullable(), $t->integer('old_customer_id')->nullable(), $t->timestamps()]);
        $this->orderStatusFixtures();
        DB::table('order_statuses')->where('code', 'new')->update(['name_az' => 'Sifariş verildi']);
        DB::table('order_statuses')->where('code', 'sent')->update(['name_az' => 'Yola çıxdı']);

        Role::create(['name' => 'Admin', 'guard_name' => 'admin']);
        $this->admin = User::forceCreate(['name' => 'Rufat']);
        $this->admin->assignRole('Admin');
        Carbon::setTestNow('2026-10-02 15:00:00');
    }

    protected function tearDown(): void
    {
        Carbon::setTestNow();
        parent::tearDown();
    }

    private function order(string $at, float $total, string $status = 'new', int $method = 1, float $cost = 0, float $fee = 0): Order
    {
        $order = Order::forceCreate(['order_status_id' => DB::table('order_statuses')->where('code', $status)->value('id'), 'total' => $total, 'payment_method_id' => $method, 'delivery_fee' => $fee]);
        $order->forceFill(['created_at' => $at])->save();
        if ($cost) {
            $item = DB::table('order_items')->insertGetId(['order_id' => $order->id]);
            DB::table('order_item_allocations')->insert(['order_item_id' => $item, 'quantity' => 1, 'unit_cost' => $cost, 'status' => 'picked']);
        }

        return $order;
    }

    public function test_stats_compare_with_previous_period_and_skip_cancelled(): void
    {
        $this->order('2026-10-02 10:00', 100);
        $this->order('2026-10-02 11:00', 300, 'sent');
        $this->order('2026-10-02 12:00', 999, 'cancelled');
        $this->order('2026-10-01 09:00', 200, 'delivered');   // dünən bu saata qədər
        $this->order('2026-10-01 18:00', 500, 'delivered');   // dünən bu saatdan sonra — müqayisəyə düşmür
        DB::table('customers')->insert([
            ['name' => 'Yeni', 'old_customer_id' => null, 'created_at' => '2026-10-02 09:00'],
            ['name' => 'Köçürülən', 'old_customer_id' => 7, 'created_at' => '2026-10-02 09:00'],
        ]);

        $stats = app(AdminDashboard::class)->stats('today');

        $this->assertSame(2, $stats['orders']['value']);
        $this->assertSame(1, $stats['orders']['previous']);
        $this->assertSame(100.0, $stats['orders']['change']);
        $this->assertSame(400.0, $stats['revenue']['value']);
        $this->assertSame(200.0, $stats['revenue']['previous']);
        $this->assertSame(200.0, $stats['average']['value']);
        $this->assertSame(1, $stats['customers']['value']);
        $this->assertNull($stats['customers']['change']);
    }

    public function test_profit_counts_only_delivered_orders_and_payment_split(): void
    {
        $this->order('2026-10-02 10:00', 205, 'delivered', 1, 120, 5);   // mal 200 − alış 120 = 80
        $this->order('2026-10-02 11:00', 300, 'delivered', 3, 250);       // 300 − 250 = 50
        $this->order('2026-10-02 12:00', 400, 'sent', 3, 300);            // hələ təhvil verilməyib
        $this->order('2026-10-02 13:00', 999, 'cancelled', 2);
        DB::table('order_item_allocations')->insert(['order_item_id' => 1, 'quantity' => 1, 'unit_cost' => 500, 'status' => 'cancelled']);

        $service = app(AdminDashboard::class);
        $profit = $service->stats('today')['profit'];
        $this->assertSame(130.0, $profit['value']);
        $this->assertSame(2, $profit['orders']);
        $this->assertSame(26.0, $profit['margin']);

        $split = collect($service->paymentMethods('today'))->keyBy('code');
        $this->assertSame(['birbank_installment', 'cash'], $split->keys()->all()); // ləğv olunan kart xaric, məbləğə görə
        $this->assertSame(700.0, $split['birbank_installment']['sum']);
        $this->assertSame(2, $split['birbank_installment']['orders']);
    }

    public function test_week_period_compares_with_same_moment_last_week(): void
    {
        $this->order('2026-09-28 10:00', 100);   // bu həftənin bazar ertəsi
        $this->order('2026-09-23 10:00', 40);    // keçən çərşənbə — keçən həftə bu vaxta qədər
        $this->order('2026-09-26 10:00', 999);   // keçən şənbə — müqayisəyə düşmür
        $revenue = app(AdminDashboard::class)->stats('week')['revenue'];
        $this->assertSame(100.0, $revenue['value']);
        $this->assertSame(40.0, $revenue['previous']);
    }

    public function test_sales_series_and_active_statuses(): void
    {
        $this->order('2026-10-02 10:00', 100);
        $this->order('2026-09-30 10:00', 50, 'sent');
        $this->order('2026-09-20 10:00', 70); // 7 gündən köhnə

        $service = app(AdminDashboard::class);
        $sales = $service->sales(7);
        $this->assertCount(7, $sales['revenue']);
        $this->assertSame('Bu gün', end($sales['labels']));
        $this->assertSame(100.0, end($sales['revenue']));
        $this->assertSame([0, 0, 0, 0, 1, 0, 1], $sales['orders']);

        $active = collect($service->activeStatuses())->pluck('count', 'code');
        $this->assertSame(2, $active['new']);
        $this->assertSame(1, $active['sent']);
    }

    public function test_main_page_renders_for_admin(): void
    {
        $this->order('2026-10-02 10:00', 100);
        $html = $this->actingAs($this->admin, 'admin')->get(route('admin.main', ['period' => 'week']))
            ->assertOk()->getContent();

        foreach (['Statistika', 'Bu həftə', 'Dövriyyə', 'Mənfəət', 'Qapıda nağd', 'dashRevenueChart', 'dashPaymentsChart'] as $text) {
            $this->assertStringContainsString($text, $html);
        }
        if ($dump = env('DASHBOARD_HTML_DUMP')) {
            file_put_contents($dump, $html);
        }
    }
}
