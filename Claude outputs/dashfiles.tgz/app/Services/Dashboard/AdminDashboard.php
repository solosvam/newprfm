<?php

namespace App\Services\Dashboard;

use App\Models\Customer\Customer;
use App\Models\Order\Order;
use App\Models\Order\OrderStatus;
use App\Models\Procurement\OrderItemAllocation;
use Carbon\CarbonImmutable;
use Carbon\CarbonInterface;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

/**
 * Admin əsas səhifəsinin göstəriciləri.
 *  - Dövriyyə: ləğv edilməmiş sifarişlərin yekun məbləği (sifariş tarixinə görə).
 *  - Mənfəət: təhvil verilmiş sifarişlərdə mal satışı (yekun − çatdırılma − bükmə) − anbardan alış dəyəri.
 *  - Yeni müştərilər: köhnə sistemdən köçürülənlər (old_customer_id) xaric.
 * Dövr cari təqvim dövrüdür (bu gün / bu həftə / bu ay) və əvvəlki dövrün EYNİ anına qədəri ilə müqayisə olunur
 * (məs. çərşənbə 15:00 → keçən çərşənbə 15:00-a qədər), yoxsa dövrün əvvəlində həmişə "−90%" görünərdi.
 * Nəticələr qısa müddət keşdə saxlanılır — hər açılışda böyük cədvəllər sayılmasın.
 */
class AdminDashboard
{
    public const PERIODS = [
        'today' => 'Bu gün',
        'week' => 'Bu həftə',
        'month' => 'Bu ay',
    ];

    public const PREVIOUS = [
        'today' => 'Dünən bu vaxta qədər',
        'week' => 'Keçən həftə bu vaxta qədər',
        'month' => 'Keçən ay bu vaxta qədər',
    ];

    /** Hələ bitməmiş (aktiv) sifariş mərhələləri — axın sırası ilə */
    public const ACTIVE_STATUSES = [
        'new' => 'send',
        'preparing' => 'box',
        'warehouse_requested' => 'hourglass',
        'warehouses_assigned' => 'boxes',
        'courier_assigned' => 'user',
        'sent' => 'delivery-truck',
        'at_address' => 'pin',
    ];

    private const TTL = 300;

    public static function period(?string $period): string
    {
        return array_key_exists((string) $period, self::PERIODS) ? $period : 'today';
    }

    /**
     * Seçilmiş dövr və əvvəlki dövrün eyni anına qədəri üzrə əsas göstəricilər.
     *
     * @return array<string, array{value: float|int, previous: float|int, change: ?float}>
     */
    public function stats(string $period): array
    {
        $period = self::period($period);

        return Cache::remember("admin-dashboard:stats:$period", self::TTL, function () use ($period) {
            [$from, $to, $prevFrom, $prevTo] = $this->range($period);
            $current = $this->orderTotals($from, $to);
            $previous = $this->orderTotals($prevFrom, $prevTo);
            $profit = $this->profit($from, $to);
            $prevProfit = $this->profit($prevFrom, $prevTo);
            $customers = fn ($a, $b) => Customer::whereNull('old_customer_id')->whereBetween('created_at', [$a, $b])->count();

            return [
                'revenue' => $this->metric($current['sum'], $previous['sum']),
                'profit' => $this->metric($profit['profit'], $prevProfit['profit']) + [
                    'orders' => $profit['orders'],
                    'margin' => $profit['sales'] > 0 ? round($profit['profit'] / $profit['sales'] * 100, 1) : null,
                ],
                'orders' => $this->metric($current['count'], $previous['count']),
                'average' => $this->metric(
                    $current['count'] ? round($current['sum'] / $current['count'], 2) : 0,
                    $previous['count'] ? round($previous['sum'] / $previous['count'], 2) : 0,
                ),
                'customers' => $this->metric($customers($from, $to), $customers($prevFrom, $prevTo)),
            ];
        });
    }

    /**
     * Seçilmiş dövrdə ödəniş üsulları üzrə bölgü (ləğv edilməmiş sifarişlər), məbləğə görə azalan.
     *
     * @return array<int, array{code: string, name: string, orders: int, sum: float, share: float}>
     */
    public function paymentMethods(string $period): array
    {
        $period = self::period($period);

        return Cache::remember("admin-dashboard:payment-methods:$period", self::TTL, function () use ($period) {
            [$from, $to] = $this->range($period);
            $rows = $this->validOrders()
                ->join('payment_methods', 'payment_methods.id', '=', 'orders.payment_method_id')
                ->whereBetween('orders.created_at', [$from, $to])
                ->groupBy('payment_methods.id', 'payment_methods.code', 'payment_methods.name_az', 'payment_methods.name')
                ->selectRaw('payment_methods.code, COALESCE(payment_methods.name_az, payment_methods.name) as name, COUNT(*) as orders, SUM(orders.total) as total_sum')
                ->orderByDesc('total_sum')
                ->get();
            $all = (float) $rows->sum('total_sum');

            return $rows->map(fn ($r) => [
                'code' => $r->code,
                'name' => $r->name,
                'orders' => (int) $r->orders,
                'sum' => round((float) $r->total_sum, 2),
                'share' => $all > 0 ? round((float) $r->total_sum / $all * 100, 1) : 0.0,
            ])->all();
        });
    }

    /**
     * Son N gün üzrə günlük dövriyyə və sifariş sayı (qrafik üçün, bu gün daxil).
     *
     * @return array{labels: string[], revenue: float[], orders: int[], dates: string[]}
     */
    public function sales(int $days = 7): array
    {
        return Cache::remember("admin-dashboard:sales:$days", self::TTL, function () use ($days) {
            $start = CarbonImmutable::today()->subDays($days - 1);
            $rows = $this->validOrders()
                ->where('created_at', '>=', $start)
                ->selectRaw('DATE(created_at) as day, COUNT(*) as orders, SUM(total) as revenue')
                ->groupBy('day')
                ->get()
                ->keyBy('day');

            $weekdays = ['B.', 'B.e.', 'Ç.a.', 'Ç.', 'C.a.', 'C.', 'Ş.'];
            $result = ['labels' => [], 'dates' => [], 'revenue' => [], 'orders' => []];
            for ($i = 0; $i < $days; $i++) {
                $day = $start->addDays($i);
                $row = $rows->get($day->toDateString());
                $result['labels'][] = $day->isToday() ? 'Bu gün' : $weekdays[$day->dayOfWeek].' '.$day->format('d.m');
                $result['dates'][] = $day->toDateString();
                $result['revenue'][] = round((float) ($row->revenue ?? 0), 2);
                $result['orders'][] = (int) ($row->orders ?? 0);
            }

            return $result;
        });
    }

    /**
     * Aktiv sifarişlərin mərhələlər üzrə sayı (axın sırası ilə, 0 olanlar da göstərilir).
     *
     * @return array<int, array{code: string, name: string, icon: string, count: int}>
     */
    public function activeStatuses(): array
    {
        return Cache::remember('admin-dashboard:active-statuses', 60, function () {
            $statuses = OrderStatus::whereIn('code', array_keys(self::ACTIVE_STATUSES))->get()->keyBy('code');
            $counts = Order::whereIn('order_status_id', $statuses->pluck('id'))
                ->selectRaw('order_status_id, COUNT(*) as total')
                ->groupBy('order_status_id')
                ->pluck('total', 'order_status_id');

            $result = [];
            foreach (self::ACTIVE_STATUSES as $code => $icon) {
                if ($status = $statuses->get($code)) {
                    $result[] = [
                        'code' => $code,
                        'name' => $status->name_az,
                        'icon' => $icon,
                        'count' => (int) ($counts[$status->id] ?? 0),
                    ];
                }
            }

            return $result;
        });
    }

    /** Ləğv edilməmiş sifarişlər */
    private function validOrders()
    {
        $cancelled = OrderStatus::where('code', 'cancelled')->value('id');

        return Order::query()->when($cancelled, fn ($q) => $q->where(
            fn ($w) => $w->where('orders.order_status_id', '!=', $cancelled)->orWhereNull('orders.order_status_id')
        ));
    }

    /** @return array{count: int, sum: float} */
    private function orderTotals(CarbonImmutable $from, CarbonImmutable $to): array
    {
        $row = $this->validOrders()
            ->whereBetween('created_at', [$from, $to])
            ->selectRaw('COUNT(*) as orders, COALESCE(SUM(total), 0) as revenue')
            ->first();

        return ['count' => (int) $row->orders, 'sum' => round((float) $row->revenue, 2)];
    }

    /**
     * Təhvil verilmiş sifarişlər üzrə mənfəət.
     * Mal satışı = yekun − çatdırılma − hədiyyə bükməsi (endirim və ləğv olunan məhsullar yekunda artıq çıxılıb);
     * alış = anbardan götürülən hissələrin (ləğv/qaytarılma xaric) miqdar × alış qiyməti.
     *
     * @return array{sales: float, cost: float, profit: float, orders: int}
     */
    private function profit(CarbonImmutable $from, CarbonImmutable $to): array
    {
        $delivered = OrderStatus::where('code', 'delivered')->value('id');
        if (!$delivered) {
            return ['sales' => 0.0, 'cost' => 0.0, 'profit' => 0.0, 'orders' => 0];
        }
        $orders = Order::where('order_status_id', $delivered)->whereBetween('created_at', [$from, $to]);

        $sales = (clone $orders)
            ->selectRaw('COUNT(*) as orders, COALESCE(SUM(total - COALESCE(delivery_fee, 0) - COALESCE(gift_wrap_fee, 0)), 0) as sales')
            ->first();
        $cost = (float) DB::table('order_item_allocations')
            ->join('order_items', 'order_items.id', '=', 'order_item_allocations.order_item_id')
            ->whereIn('order_items.order_id', (clone $orders)->select('id'))
            ->whereNotIn('order_item_allocations.status', OrderItemAllocation::SUPPLY_INACTIVE)
            ->sum(DB::raw('order_item_allocations.quantity * order_item_allocations.unit_cost'));

        $salesSum = round((float) $sales->sales, 2);

        return [
            'sales' => $salesSum,
            'cost' => round($cost, 2),
            'profit' => round($salesSum - $cost, 2),
            'orders' => (int) $sales->orders,
        ];
    }

    /**
     * Cari dövr [başlanğıc, indi] və əvvəlki dövr [başlanğıc, eyni an].
     *
     * @return array{0: CarbonImmutable, 1: CarbonImmutable, 2: CarbonImmutable, 3: CarbonImmutable}
     */
    private function range(string $period): array
    {
        $now = CarbonImmutable::now();

        return match ($period) {
            'week' => [$now->startOfWeek(CarbonInterface::MONDAY), $now, $now->startOfWeek(CarbonInterface::MONDAY)->subWeek(), $now->subWeek()],
            // ayın 31-i keçən ayda yoxdursa, keçən ayın sonuna qədər
            'month' => [$now->startOfMonth(), $now, $now->startOfMonth()->subMonthNoOverflow(), $now->subMonthNoOverflow()],
            default => [$now->startOfDay(), $now, $now->startOfDay()->subDay(), $now->subDay()],
        };
    }

    private function metric(float|int $value, float|int $previous): array
    {
        return [
            'value' => $value,
            'previous' => $previous,
            // əvvəlki dövr 0 və ya mənfidirsə faiz mənasızdır
            'change' => $previous > 0 ? round(($value - $previous) / $previous * 100, 1) : null,
        ];
    }
}
