{{--
  Əsas səhifə: admin/operator paneli.
  $dashboard = ['period', 'stats' (AdminDashboard::stats), 'payments' (ödəniş üsulları), 'sales' (son 7 gün)]
--}}
@use('App\Services\Dashboard\AdminDashboard')
@php
    $period = $dashboard['period'];
    $money = fn ($v, $d = 0) => number_format((float) $v, $d, '.', ' ');
    $stats = $dashboard['stats'];
    $cards = [
        ['key' => 'revenue', 'title' => 'Dövriyyə', 'icon' => 'money', 'format' => fn ($v) => $money($v).' ₼'],
        ['key' => 'profit', 'title' => 'Mənfəət', 'icon' => 'trend-up', 'format' => fn ($v) => $money($v).' ₼'],
        ['key' => 'orders', 'title' => 'Sifarişlər', 'icon' => 'cart', 'format' => fn ($v) => $money($v)],
        ['key' => 'average', 'title' => 'Orta sifariş', 'icon' => 'basket', 'format' => fn ($v) => $money($v, 2).' ₼'],
    ];
    $sales = $dashboard['sales'];

    // Ödəniş üsulları: 4 rəng — çox olarsa, ən kiçikləri "Digər"də birləşir
    $colors = ['primary', 'secondary', 'tertiary', 'quaternary'];
    $payments = collect($dashboard['payments']);
    if ($payments->count() > count($colors)) {
        $rest = $payments->slice(count($colors) - 1);
        $payments = $payments->take(count($colors) - 1)->push([
            'name' => 'Digər', 'orders' => $rest->sum('orders'), 'sum' => $rest->sum('sum'), 'share' => round($rest->sum('share'), 1),
        ]);
    }
    $paymentTotal = $payments->sum('sum');
@endphp

<div class="row">
    {{-- Statistika (dövr seçimi ilə) --}}
    <div class="col-12 col-xl-6 mb-5">
        <div class="d-flex align-items-center">
            <div class="dropdown me-3">
                <a class="pe-0 pt-0 align-top lh-1 dropdown-toggle small-title" href="#" data-bs-toggle="dropdown" aria-expanded="false" aria-haspopup="true">
                    {{ AdminDashboard::PERIODS[$period] }}
                </a>
                <div class="dropdown-menu font-standard">
                    @foreach(AdminDashboard::PERIODS as $key => $label)
                        <a class="dropdown-item text-medium {{ $key === $period ? 'active' : '' }}"
                           href="{{ route('admin.main', ['period' => $key]) }}">{{ $label }}</a>
                    @endforeach
                </div>
            </div>
            <h2 class="small-title">Statistika</h2>
        </div>
        <div class="row g-2">
            @foreach($cards as $card)
                @php($m = $stats[$card['key']])
                <div class="col-12 col-sm-6">
                    <div class="card h-100 sh-xl-24">
                        <div class="h-100 row g-0 card-body align-items-center py-4">
                            <div class="col-auto">
                                <div class="bg-gradient-light sw-6 sh-6 rounded-md d-flex justify-content-center align-items-center">
                                    <i data-acorn-icon="{{ $card['icon'] }}" class="text-white"></i>
                                </div>
                            </div>
                            <div class="col ps-3 d-flex flex-column justify-content-center">
                                <div class="heading mb-1 lh-1-25">
                                    {{ $card['title'] }}
                                    @if($card['key'] === 'profit' && $m['margin'] !== null)
                                        <span class="badge bg-outline-primary ms-1" title="Mal satışına nisbətən">{{ $m['margin'] }}%</span>
                                    @endif
                                </div>
                                <div class="row g-0 align-items-center">
                                    <div class="col-auto">
                                        <div class="cta-2 {{ $card['key'] === 'profit' && $m['value'] < 0 ? 'text-danger' : 'text-primary' }}">{{ $card['format']($m['value']) }}</div>
                                    </div>
                                    @if($m['change'] !== null)
                                        <div class="col {{ $m['change'] >= 0 ? 'text-success' : 'text-danger' }} d-flex align-items-center ps-3">
                                            <i data-acorn-icon="{{ $m['change'] >= 0 ? 'arrow-top' : 'arrow-bottom' }}" class="me-1" data-acorn-size="13"></i>
                                            <span class="text-medium">{{ ($m['change'] > 0 ? '+' : '').$m['change'] }}%</span>
                                        </div>
                                    @endif
                                </div>
                                <div class="text-small text-muted mt-1">
                                    @if($card['key'] === 'profit')
                                        {{ $m['orders'] }} təhvil verilmiş sifariş üzrə
                                    @else
                                        {{ AdminDashboard::PREVIOUS[$period] }}: {{ $card['format']($m['previous']) }}
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    {{-- Satış dinamikası: son 7 gün --}}
    <div class="col-12 col-xl-6 mb-5">
        <h2 class="small-title">Satış — son 7 gün</h2>
        @foreach([
            ['id' => 'dashRevenueChart', 'label' => 'Dövriyyə, ₼', 'data' => $sales['revenue'], 'total' => $money(array_sum($sales['revenue'])).' ₼', 'avg' => $money(array_sum($sales['revenue']) / 7).' ₼', 'color' => 'primary'],
            ['id' => 'dashOrdersChart', 'label' => 'Sifarişlər', 'data' => $sales['orders'], 'total' => array_sum($sales['orders']), 'avg' => $money(array_sum($sales['orders']) / 7, 1), 'color' => 'secondary'],
        ] as $chart)
            <div class="card h-auto sh-xl-24 {{ $loop->first ? 'mb-2' : '' }}">
                <div class="card-body">
                    <div class="row g-0 h-100 chart-container">
                        {{-- Yuxarı hissəni (seçilmiş gün) charts.extend.js doldurur --}}
                        <div class="col-12 col-sm-auto d-flex flex-column justify-content-between custom-tooltip pe-0 pe-sm-4 sw-sm-19">
                            <p class="heading title mb-1"></p>
                            <div>
                                <div>
                                    <div class="cta-2 text-{{ $chart['color'] }} value d-inline-block align-middle"></div>
                                    <i class="icon d-inline-block align-middle text-{{ $chart['color'] }}" data-acorn-size="15"></i>
                                </div>
                                <div class="text-small text-muted mb-1 text"></div>
                            </div>
                            <div class="row g-3 flex-nowrap">
                                <div class="col-auto">
                                    <div class="cta-4 text-alternate text-nowrap">{{ $chart['total'] }}</div>
                                    <div class="text-small text-muted mb-1">7 GÜN</div>
                                </div>
                                <div class="col-auto">
                                    <div class="cta-4 text-alternate text-nowrap">{{ $chart['avg'] }}</div>
                                    <div class="text-small text-muted mb-1">GÜNDƏ ORTA</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm sh-17">
                            <canvas id="{{ $chart['id'] }}" class="dashboard-line-chart"
                                    data-label="{{ $chart['label'] }}"
                                    data-color="{{ $chart['color'] }}"
                                    data-labels='@json($sales['labels'])'
                                    data-values='@json($chart['data'])'></canvas>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

{{-- Ödəniş üsulları üzrə bölgü (seçilmiş dövr) --}}
<div class="row">
    <div class="col-12 col-xl-6 mb-5">
        <h2 class="small-title">Ödəniş üsulları — {{ mb_strtolower(AdminDashboard::PERIODS[$period]) }}</h2>
        <div class="card h-100-card">
            <div class="card-body">
                @if($payments->isEmpty())
                    <div class="text-muted text-center py-5">Bu dövrdə sifariş yoxdur</div>
                @else
                    <div class="row g-0 align-items-center">
                        <div class="col-12 col-sm-5 mb-4 mb-sm-0">
                            <div class="position-relative sh-25">
                                <canvas id="dashPaymentsChart"
                                        data-labels='@json($payments->pluck('name'))'
                                        data-values='@json($payments->pluck('sum'))'
                                        data-colors='@json(array_slice($colors, 0, $payments->count()))'></canvas>
                                <div class="position-absolute top-50 start-50 translate-middle text-center pe-none">
                                    <div class="text-small text-muted text-uppercase">Cəmi</div>
                                    <div class="cta-3 text-primary">{{ $money($paymentTotal) }} ₼</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-7 ps-sm-5">
                            @foreach($payments->values() as $i => $method)
                                <div class="row g-0 align-items-center {{ $loop->last ? '' : 'mb-4' }}">
                                    <div class="col-auto">
                                        <div class="sw-5 sh-5 rounded-xl border border-{{ $colors[$i] }} d-flex justify-content-center align-items-center">
                                            <i data-acorn-icon="{{ ['cash' => 'money', 'card_online' => 'credit-card', 'bonus_balance' => 'gift'][$method['code'] ?? ''] ?? 'wallet' }}" class="text-{{ $colors[$i] }}" data-acorn-size="18"></i>
                                        </div>
                                    </div>
                                    <div class="col ps-3">
                                        <div class="d-flex justify-content-between align-items-end">
                                            <div class="lh-1-25">
                                                {{ $method['name'] }}
                                                <div class="text-small text-muted">{{ $method['orders'] }} sifariş · {{ $money($method['sum']) }} ₼</div>
                                            </div>
                                            <div class="cta-3 text-{{ $colors[$i] }}">{{ $method['share'] }}%</div>
                                        </div>
                                        <div class="progress dashboard-progress mt-2">
                                            <div class="progress-bar bg-{{ $colors[$i] }}" role="progressbar" style="width: {{ $method['share'] }}%"
                                                 aria-valuenow="{{ $method['share'] }}" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
